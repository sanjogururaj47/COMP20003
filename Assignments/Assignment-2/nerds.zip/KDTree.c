/** *******************************************************
 * 
 * Inlcudes the function definition for the tree data structures operations
 * 
 */

#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include<string.h>
#include<math.h>
#include<float.h>

#include "KDTree.h"

/** *******************************************************/

#define TRUE 1
#define FALSE 0

/* function to insert a node into a singly linked list */

/* function to create a new node for a tree */
tree_t* new_node(double *x, double *y, data_t *data) {

    tree_t *new_node = (tree_t *)malloc(1*sizeof(tree_t));
    assert(new_node != NULL);

    new_node->l_list = insert_linked_list(data, data->value);
    new_node->x_key = x;
    new_node->y_key = y;

    new_node->left = new_node->right = NULL;

    return new_node;
}

data_t* insert_linked_list(data_t *list, char *value) {
    //tree_t *insert_node = root;

    data_t *new_node = (data_t *)malloc(1*sizeof(data_t));
    assert(new_node != NULL);
    //printf("pakks this kebal only\n");
    new_node->value = value;
    new_node->next = list;
    return new_node;
}

void traverse_linked_list(data_t *head, FILE *fp_out) {
    //printf("is this function fucking getting called mate\n\n");
    //printf("data: %s\n", data->value);
    data_t *temp = head;
    while(temp->next != NULL) {
        //printf("macha fuck rah\n");
        fprintf(fp_out, "%s\n", temp->value);
        printf("%s\n\n\n\n\n\n\n", temp->value);
        temp = temp->next;
    }
}

int same_node(tree_t *root, double *x, double *y) {
    //printf("in same node uh\n");

    if((fabs(*(root->x_key) - *x) < DBL_EPSILON) && (fabs(*(root->y_key) - *y) < DBL_EPSILON)) {
        return TRUE;
    }
    return FALSE;
}

/* function to recursively insert into the tree */
tree_t* tree_insert(tree_t *root, double *x, double *y, data_t *data, unsigned depth) {

    //printf("y_key: %.8lf\n\n", *y);

    //printf("inside insert\n");

    if (root == NULL) return new_node(x, y, data);
    //depth += 1;
    //printf("ohhh wait is it here?\n");

    if(same_node(root, x, y)) {
        //printf("how tf: %.8lf and %.8lf\n", *(root->x_key), *x);
        root->l_list = insert_linked_list(root->l_list, data->value);
        return root;
    }
    //printf("pakks this kebal only\n");
    /* check the depth of the tree */
    if(depth%2 == 0) {
        //printf("X is being compared with depth = %d\n", depth);
        //printf("%.8lf compared with %.8lf\n", *x, *(root->x_key));
        if(*x < *(root->x_key)) {
            //printf("going to the left\n");
            root->left = tree_insert(root->left, x, y, data, depth + 1);

            
        }
        else if(*x >= *(root->x_key)) {
            //printf("going to the right\n");
            root->right = tree_insert(root->right, x, y, data, depth + 1);
            
        }
    }
    
    else {
        //printf("Y is being compared with depth = %d\n", depth);
        //printf("%.8lf compared with %.8lf\n", *y, *(root->y_key));
        if(*y < *(root->y_key)) { 
            //printf("going to the left\n");
            root->left = tree_insert(root->left, x, y, data, depth + 1);
            
        }
        else if(*y >= *(root->y_key)) {
            //printf("Going to the right\n");
            root->right = tree_insert(root->right, x, y, data, depth + 1); 
            
        }
    }

    return root;
}

tree_t* search_tree(tree_t *root, double *x, double *y, unsigned depth, double *dist, tree_t *closest_node) {

    //printf("coming here?\n\n\n\n\n");
    //printf("closest: %s\n", closest_node->data->value);
    //printf("root: %s\n\n\n\n\n\n\n", root->data->value);
    //printf("\n\n\nDISTANCE: %lf\n\n\n", dist);

    if(root == NULL) {
        return closest_node;
    }

    //printf("\n\n\nROOT X KEY %.8lf\n\n", *(root->x_key));

    if((fabs(*(root->x_key) - *x) < DBL_EPSILON) && (fabs(*(root->y_key) - *y) < DBL_EPSILON)) {
        //printf("FOUND\n\n\n");
        closest_node = root;
        //printf("RESULT in the function (fabs): %.8lf\n\n\n", *(closest_node->x_key));

        return closest_node;
    }
    //printf("coming here?\n\n\n\n\n");

    //if(closest_node == NULL) printf("null as fuck homie\n\n\n\n\n\n");
    
    //printf("coming here?\n\n\n\n\n");

    double x_diff = fabs(*(root->x_key) - *x);
    double y_diff = fabs(*(root->y_key) - *y);
    double curr_dist = sqrt(pow(x_diff,2) + pow(y_diff,2));
    //printf("curr distance and distance: %lf, %lf\n", curr_dist, dist);

    if(curr_dist <= *dist) {
        //printf("came off inside\n\n\n\n\n");
        *dist = curr_dist;
        //printf("Here uh\n\n\n");
        closest_node = root;
        //printf("or here?\n\n\n");

        //closest_node = search_tree(root->left, x, y, depth + 1, dist, closest_node);
        //closest_node = search_tree(root->right, x, y, depth + 1, dist, closest_node); 
    }
    
    

    
    if(depth%2 == 0) {
        //printf("X is being compared with depth = %d\n", depth);
        //printf("%.8lf compared with %.8lf\n", *x, *(root->x_key));
        if(x_diff <= *dist) {
            closest_node = search_tree(root->left, x, y, depth + 1, dist, closest_node);
            closest_node = search_tree(root->right, x, y, depth + 1, dist, closest_node);  
        }
        if(*x < *(root->x_key)) {
            //printf("going to the left\n");
            closest_node = search_tree(root->left, x, y, depth + 1, dist, closest_node);
                
            }
        else if(*x >= *(root->x_key)) {
            //printf("going to the right\n");
            closest_node = search_tree(root->right, x, y, depth + 1, dist, closest_node);
            
        }
    }
    
    else {
        //printf("Y is being compared with depth = %d\n", depth);
        //printf("%.8lf compared with %.8lf\n", *y, *(root->y_key));
        if(y_diff <= *dist) {
            closest_node = search_tree(root->left, x, y, depth + 1, dist, closest_node);
            closest_node = search_tree(root->right, x, y, depth + 1, dist, closest_node);  
        }
        if(*y < *(root->y_key)) { 
            //printf("going to the left\n");
            closest_node = search_tree(root->left, x, y, depth + 1, dist, closest_node); 
            
        }
        else if(*y >= *(root->y_key)) {
            //printf("Going to the right\n");
            closest_node = search_tree(root->right, x, y, depth + 1, dist, closest_node);  
            
        }
    }
    return closest_node;
}

void search_tree_radius(tree_t *root, double *x, double *y, unsigned depth, double *radius, int *found) {

    //printf("reached here!!\n\n");
    if(root == NULL) {
        if(!(*found)) printf("NOT FOUND\n");
        return;
    }

    //search_tree_radius(root->left, x, y, depth + 1, radius, found);

    //search_tree_radius(root->right, x, y, depth + 1, radius, found);

    //printf("reached here!!\n\n");

   double curr_dist = sqrt(pow(*x - *(root->x_key),2) + pow(*y - *(root->y_key),2));
   printf("distance to the node: %lf is %lf\n\n", *(root->x_key), curr_dist);

   //printf("macha here uh?\n\n");

   if(curr_dist < *radius) {
       //printf("after this?\n\n\n");
       *found = TRUE;
       //printf("or here?\n\n\n");
       //printf("data: %s\n\n\n\n\n", root->data->value);
   }

    //printf("reached here!!\n\n");

    if(depth%2 == 0) {
        //printf("X is being compared with depth = %d\n", depth);
       //printf("%.8lf compared with %.8lf\n", *x, *(root->x_key));
        if(*x < *(root->x_key)) {
                //printf("going to the left\n");
                search_tree_radius(root->left, x, y, depth + 1, radius, found);
                
            }
            else if(*x >= *(root->x_key)) {
                //printf("going to the right\n");
                search_tree_radius(root->right, x, y, depth + 1, radius, found);
                
            }
        }
    
    else {
        //printf("Y is being compared with depth = %d\n", depth);
        //printf("%.8lf compared with %.8lf\n", *y, *(root->y_key));
        if(*y < *(root->y_key)) { 
            //printf("going to the left\n");
            search_tree_radius(root->left, x, y, depth + 1, radius, found);
            
        }
        else if(*y >= *(root->y_key)) {
            //printf("Going to the right\n");
            search_tree_radius(root->right, x, y, depth + 1, radius, found);
            
        }
    }

}

/* Given a binary tree, print its nodes in inorder*/
/* void searchInorder(tree_t *root, double x, double y) 
{ 
     if (root == NULL) 
          return; 
  
     /* first recur on left child 
     printInorder(root->left); 
  
     /* then print the data of node 
     printf("%d ", root->data);   
  
     /* now recur on right child 
     printInorder(root->right); 
}  */


//int count = 0;

void traverse_tree(tree_t *root, FILE *fp_out) {

    //printf("number of collisions: %d\n\n", count2);
    if(root == NULL) return;

    printf("from traverse\n");
    //printf("y_key: %lf\n", *(root->y_key));
    fprintf(fp_out, "%s\n", root->l_list->value);
    printf("%s\n\n\n\n\n", root->l_list->value);
    if(root->l_list->next != NULL) {
        //count++;
        //printf("IT HAS A NEXT MATE!!\n\n\n");
        //fprintf("data: %s\n", root->data->value);
        traverse_linked_list(root->l_list->next, fp_out);
        
    }

    /* recurse on the right */
    traverse_tree(root->right, fp_out);

    /* recurse on the left */
    traverse_tree(root->left, fp_out);
    //printf("count: %d\n", count);
}

/* void print_result(tree_t *root, FILE *fp_out) {

    /* print the key 
    printf("%.7lf %.8lf --> ", key);
    fprintf(fp_out, "%s --> ", key);

    /* copy the first row of the csv file containing column headers 
    char column_header[strlen(columns)];
    char value[strlen(val)];

    /* pointers for strtok_r() 
    char *save_ptr1, *save_ptr2;

    strcpy(column_header, columns);
    strcpy(value, val);

    /* set delimiters for strtok_r() 
    const char col_delim[2] = ",";
    const char val_delim[2] = "~";

    /* get the first token 
    char *col_token = strtok_r(column_header, col_delim, &save_ptr1);
    char *value_token = strtok_r(value, val_delim, &save_ptr2);

    while(value_token != NULL &&  col_token != NULL) {

        /* print the tokens in the specified format 
        printf("%s: %s || ", col_token, value_token);
        fprintf(fp_out, "%s: %s || ", col_token, value_token);

        /* get the subsequent tokens 
        col_token = strtok_r(NULL, col_delim, &save_ptr1); 
        value_token = strtok_r(NULL, val_delim, &save_ptr2); 
    }
    fprintf(fp_out, "\n");
} */