/** *******************************************************
 * Program read data from a csv file, and 
 * Implement a KD-Tree for storage and search
 *      
 * Code written for Assignment 2 COMP20003, S2 2020.
 *      By Sanjog Gururaj, Student ID - 1099103
 * 
 * Algorithms and Data Structures are both fun!
 */


#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include<assert.h>
#include<math.h>
#include<float.h>

/* custom header files */
#include "read.h"
#include "KDTree.h"

/** *******************************************************/

#define TRUE 1
#define FALSE 0
#define COMPLETE 0
#define KEY_LENGTH 129
#define CSV_BUF 513

/** *******************************************************/

/** *******************************************************/

int main(int argc, char **argv) {

    tree_t *root = NULL;
    
    /* pointers to store the headers of the data */
    char *x_key_header, *y_key_header, *data_headers;

    x_key_header = (char *)malloc(KEY_LENGTH*(sizeof(char)));
    assert(x_key_header != NULL);
    y_key_header = (char *)malloc(KEY_LENGTH*(sizeof(char)));
    assert(y_key_header != NULL);
    data_headers = (char *)malloc(CSV_BUF*(sizeof(char)));
    assert(data_headers != NULL);

    /* create file pointers for reading and writing */
    FILE* fp_in = fopen(argv[1], "r");
    FILE* fp_out = fopen(argv[2], "w");

    /* check if file open failed */
    if(!fp_in) {
        printf("Failed to open input file\n");
        exit(EXIT_FAILURE);
    }
    if(!fp_out) printf("Failed to open output file\n");

    if(!read_first_row(x_key_header, y_key_header, data_headers, fp_in)) printf("reached end of file prematurely!\n");

    /* pointers to store the key and value of each line of the csv file */
    char *x_key, *y_key, *value;
    x_key = (char *)malloc(KEY_LENGTH*(sizeof(char)));
    assert(x_key != NULL);
    y_key = (char *)malloc(KEY_LENGTH*(sizeof(char)));
    assert(y_key != NULL);
    value = (char *)malloc(CSV_BUF*(sizeof(char)));
    assert(value != NULL);

    /* read and insert every line of the csv file */
    while(read_csv(x_key, y_key, value, data_headers, fp_in)) {

        /* pointers to store the key */
        double *insert_x_key, *insert_y_key;
        insert_x_key = (double *)malloc(1*sizeof(double));
        assert(insert_x_key != NULL);
        insert_y_key = (double *)malloc(1*sizeof(double));
        assert(insert_y_key != NULL);

        char *ref1, *ref2;
        *insert_x_key = strtod(x_key, &ref1);
        *insert_y_key = strtod(y_key, &ref2);

        //printf("alright double values now, xkey: %.7lf\nykey: %.8lf\n", *insert_x_key, *insert_y_key);

        /* pointers to store the value */
        /* char *insert_data;
        insert_data = (char *)malloc((strlen(val)+1)*(sizeof(char)));
        assert(insert_data != NULL); */

        data_t *data;
        data = (data_t *)malloc(1*(sizeof(data_t))); 
        assert(data != NULL);
        data->value = (char *)malloc((strlen(value)+1)*(sizeof(char)));
        assert(data->value != NULL);

        data->next = NULL;


        /* copy data into a new location */
        strcpy(data->value, value);
        //printf("okay boss hope data is also fine now %s\n", data->value);

        //printf("lines of the csv file: x_key: %s\ny_key: %s\ndata: %s\n", insert_x_key, insert_y_key, insert_data);

        /* insert into the tree */
        //if(strlen(insert_key) > 1) dict = dict_insert(dict, insert_key, insert_value);
        //printf("what is getting passed in to be inserted\n\n\n\n\ny_key: %.8lf\n", *insert_y_key);
        //printf("data: %s\n", data->value);
        //printf("\n\n\n\n\n new key getting inserted\n\n");
        if(fabs(*insert_y_key + *insert_x_key) > DBL_EPSILON) {
            printf("what is getting passed in to be inserted\n\n\n\n\nx_key: %.8lf\n", *insert_x_key);
            if (strlen(data) > 1) root = tree_insert(root, insert_x_key, insert_y_key, data, 0);
        }
    }
    
    tree_t *closest_node = root;

    //read_key_radius(root);
    //traverse_tree(root);
}


/** *******************************************************/