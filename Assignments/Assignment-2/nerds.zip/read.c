/** *******************************************************
 * 
 * includes the function definitions for reading a csv file
 * 
 */



#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include<math.h>

#include "KDTree.h"
#include "read.h"

/** *******************************************************/

#define KEY_LENGTH 129
#define TRUE 1
#define FALSE 0

/** *******************************************************/

void read_key(tree_t *root, tree_t *closest_node, FILE *fp_out) {

    double *search_x_key, *search_y_key;
    search_x_key = (double *)malloc(1*sizeof(double));
    assert(search_x_key != NULL);
    search_y_key = (double *)malloc(1*sizeof(double));
    assert(search_y_key != NULL);

    while(scanf("%lf %lf", search_x_key, search_y_key) != EOF) {

        double dist;
        dist = sqrt(pow(*search_x_key - *(root->x_key),2) 
                + pow(*search_y_key - *(root->y_key),2));
        printf("key read in is: %.8lf, %.8lf\n\n\n\n\n\n", *search_x_key, *search_y_key);
        closest_node = search_tree(root, search_x_key, search_y_key, 0, &dist, closest_node);
        //printf("HERE UH \n\n\n");
        if(closest_node != NULL) printf("RESULT: %s\n\n\n\n", closest_node->l_list->value);
        if(closest_node->l_list->next != NULL) traverse_linked_list(closest_node->l_list->next, fp_out);
        //printf("Atter this uh\n\n\n");
    } 
}

/* function to read keys from stdin */
void read_key_radius(tree_t *root) {

    double *search_x_key, *search_y_key, *radius;
    search_x_key = (double *)malloc(1*sizeof(double));
    assert(search_x_key != NULL);
    search_y_key = (double *)malloc(1*sizeof(double));
    assert(search_y_key != NULL);
    radius = (double *)malloc(1*sizeof(double));
    assert(radius != NULL);


    while(scanf("%lf %lf %lf", search_x_key, search_y_key, radius) != EOF) {

        double dist;
        dist = sqrt(pow(*search_x_key - *(root->x_key),2) 
                + pow(*search_y_key - *(root->y_key),2));
        printf("key read in is: %.8lf, %.8lf\n\n\n\n\n\n", *search_x_key, *search_y_key);
        int found = 0;
        search_tree_radius(root, search_x_key, search_y_key, 0, radius, &found);
    }
}

/* function to scan the keys from standard input */
int read_first_row(char *x_key, char *y_key, char *columns, FILE *fp_in) {

    char c;
    int num_commas = 0;
    int i = 0, j = 0;

    /* read a line of the csv file */
    while((c = fgetc(fp_in)) && c != '\n' && c != EOF && c != '\r') {

        /* arrived at the x-coordinate */
        if(num_commas == 8) {
            j = 0;
            x_key[j++] = c;

            /* copy column name into key */
            while((c = fgetc(fp_in)) && c != ',') x_key[j++] = c;

            num_commas++;
            continue;
        }

        /* arrived at the y-coordinate */
        if(num_commas == 9) {
            j = 0;
            y_key[j++] = c;

            /* copy column name into key */
            while((c = fgetc(fp_in)) && c != ',') y_key[j++] = c;

            num_commas++;
            continue;
        }

        if(c == ',') num_commas++;

        columns[i++] = c;
    }

    /* terminate the strings */
    columns[i] = '\0';
    x_key[j] = '\0';
    y_key[j] = '\0';


    if(c == EOF) return FALSE;

    return TRUE;

}

/* function to read the column headers of a csv file */
int read_csv(char *x_key, char *y_key, char *value, char *column, FILE *fp_in) {

    char c;
    int num_commas = 0;

    int i = 0, j= 0, k = 0;

    /* read a line of the csv file */
    while((c = fgetc(fp_in)) && c != '\n' && c != EOF && c != '\r') {

        /* arrived at the key column */
        if(num_commas == 8) {
            j = 0;
            /* j = 0;
            if(c == '"') {
                while((c = fgetc(fp_in))) {
                    if(c == '"') {

                        /* check if at end of column name 
                        if((c = fgetc(fp_in)) == ','){
                            num_commas++;
                            break;
                        }
                    }
                    x_key[j++] = c;
                }
                continue;
            } */

            if(c == ',') value[i++] = '~';

            value[i++] = x_key[j++] = c;

            /* copy column name into key */
            while((c = fgetc(fp_in)) && c != ',') value[i++] = x_key[j++] = c;
            if (c == ',') value[i++] = '~';
            
            num_commas++;
            continue;
        }

        else if(num_commas == 9) {
            k = 0;
            /* if(c == '"') {
                while((c = fgetc(fp_in))) {
                    if(c == '"') {

                        /* check if at end of column name 
                        if((c = fgetc(fp_in)) == ','){
                            num_commas++;
                            break;
                        }
                    }
                    y_key[k++] = c;
                }
                continue;
            } */

            if(c == ',') value[i++] = '~';
            value[i++] = y_key[k++] = c;

            /* copy column name into key */
            while((c = fgetc(fp_in)) && c != ',') value[i++] = y_key[k++] = c;
            if(c == ',') value[i++] = '~';
            
            num_commas++;
            continue; 
        }
        else {
            if(c == '"') {

                /* copy until end of second quote */
                while((c = fgetc(fp_in)) && c != '"') value[i++] = c;
                continue;
            }

            if(c == ',') {

                /* replace comma with tilde */
                value[i++] = '~';
                num_commas++;
                continue;
            }

            value[i++] = c;
        }
    }

    /* terminate the strings */
    value[i] = '\0';
    x_key[j] = '\0';
    y_key[k] = '\0';

    //printf("lines of the csv file: x_key: %s\ny_key: %s\ndata: %s\n", x_key, y_key, value);

    if(c == EOF) return FALSE;

    return TRUE;
}