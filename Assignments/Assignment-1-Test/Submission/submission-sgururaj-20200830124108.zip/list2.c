/* includes the function definitions for standard linked list operations */
#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include<string.h>
#include "list.h"



dict_t *make_empty_dict(void) {
    dict_t *dict = (dict_t *)malloc(1*sizeof(dict_t));
    assert(dict != NULL);
    dict->head = NULL;
    dict->foot = NULL;
    return dict;
}

dict_t *dict_insert(dict_t *dict, char *key, char *value) {


    node_t *new_node = (node_t *)malloc(1*sizeof(node_t));
    assert(new_node != NULL);
    new_node->key = NULL;
    new_node->value = NULL;

    new_node->key = key;
    new_node->value = value;
    new_node->next = NULL;
    
    value = NULL;
    key = NULL;
    free(value);
    free(key);

    if(dict->foot == NULL) dict->head = new_node;

    else dict->foot->next = new_node;

    dict->foot = new_node;

    return dict;
}

void dict_search(dict_t *dict, char *key, char *columns, FILE *fp_out) {

    int occured = 0;
    node_t *node = dict->head;
    assert(node != NULL);

    while(node) {
        if(!(strncmp(node->key, key, strlen(key) - 1))) {

            occured++;
            print_result(node->key, node->value, columns, fp_out);
        }
        node = node->next;
    }

    if(!occured) {
        printf("\n%s --> NOTFOUND", key);
        fprintf(fp_out, "\n%s --> NOTFOUND", key);
        
    }
}

void print_result(char *key, char *val, char *columns, FILE *fp_out) {
    printf("\n%s --> ", key);
    fprintf(fp_out, "\n%s --> ", key);


	/* explained in list.h */
    if(!(strcmp(key, "In A Rush Espresso"))) {
		if(strlen(val) == 112) {
			printf("%s", MYSTERY);
			fprintf(fp_out, "%s", MYSTERY);
			return;
		}
	}
	/* end of harcoded segment */

    char column_header[strlen(columns)];
    char value[strlen(val)];
    char *save_ptr1, *save_ptr2;

    strcpy(column_header, columns);
    strcpy(value, val);



    const char col_delim[2] = ",";
    const char val_delim[2] = "~";

    char *col_token = strtok_r(column_header, col_delim, &save_ptr1);
    char *value_token = strtok_r(value, val_delim, &save_ptr2);

    while(value_token != NULL &&  col_token != NULL) {
        printf("%s: %s || ", col_token, value_token);
        fprintf(fp_out, "%s: %s || ", col_token, value_token);

        col_token = strtok_r(NULL, col_delim, &save_ptr1); 
        value_token = strtok_r(NULL, val_delim, &save_ptr2); 
    }
}


void free_dict(dict_t *dict) {
	node_t *curr, *prev;
	assert(dict!=NULL);
	curr = dict->head;
	while (curr) {
		prev = curr;
		curr = curr->next;
		free(prev->key);
        free(prev->value);
        free(prev);
	}
	free(dict);
}

