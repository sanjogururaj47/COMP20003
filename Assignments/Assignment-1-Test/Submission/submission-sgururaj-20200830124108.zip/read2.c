#include<string.h>
#include<stdio.h>
#include<stdlib.h>

#include "list.h"
#include "read.h"

#define KEY_LENGTH 129
#define TRUE 1
#define FALSE 0


void read_key(dict_t *dict, char *columns, FILE *fp_out) {
    char key[KEY_LENGTH];

    while(fgets(key, KEY_LENGTH, stdin)) {
        /* terminate the string and delete the newline character */
        key[strlen(key) - 1] = '\0';

        dict_search(dict, key, columns, fp_out);
    }
}

int read_first_row(char *key, char *columns, FILE *fp_in) {
    char c;
    int num_commas = 0;
    int i = 0, j = 0;

    while((c = fgetc(fp_in)) && c != '\n' && c != EOF && c != '\r') {

        if(num_commas == 5) {
            j = 0;
            key[j++] = c;
            while((c = fgetc(fp_in)) && c != ',') {
                key[j++] = c;
            }
            num_commas++;
            continue;
        }

        if(c == ',') num_commas++;

        columns[i++] = c;
    }
    columns[i] = '\0';
    key[j] = '\0';

    if(c == EOF) return FALSE;

    return TRUE;

}

int read_csv(char *key, char *value, char *column, FILE *fp_in) {

    char c;
    int num_commas = 0;

    int i = 0, j= 0;

    while((c = fgetc(fp_in)) && c != '\n' && c != EOF && c != '\r') {

        if(num_commas == 5) {
            j = 0;
            if(c == '"') {
                while((c = fgetc(fp_in))) {
                    if(c == '"') {
                        if((c = fgetc(fp_in)) == ','){
                            num_commas++;
                            break;
                        }
                    }
                    key[j++] = c;
                }
                continue;
            }

            key[j++] = c;
            while((c = fgetc(fp_in)) && c != ',') {
                key[j++] = c;
            }
            num_commas++;
            continue;
        }
        else{

            if(c == '"') {
                while((c = fgetc(fp_in)) && c != '"') value[i++] = c;
                continue;
            }

            if(c == ',') {
                value[i++] = '~';
                num_commas++;
                continue;
            }

            value[i++] = c;
        }
    }
    value[i] = '\0';
    key[j] = '\0';

    if(c == EOF) return FALSE;

    return TRUE;
}